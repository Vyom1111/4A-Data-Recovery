import React from 'react';
import { motion } from 'framer-motion';
import { HardDrive, Smartphone, Server, Shield, Database, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

const services = [
  {
    icon: HardDrive,
    title: "Hard Drive Recovery",
    description: "Recovery for all types of hard drive failures, including mechanical and logical issues.",
    path: "/services/hard-drive"
  },
  {
    icon: Database,
    title: "SSD Data Recovery",
    description: "Specialized recovery techniques for solid-state drives and flash storage.",
    path: "/services/ssd"
  },
  {
    icon: Server,
    title: "RAID Recovery",
    description: "Expert recovery for all RAID configurations and server storage systems.",
    path: "/services/raid"
  },
  {
    icon: Shield,
    title: "Server Recovery",
    description: "Enterprise-level recovery solutions for server failures and data loss.",
    path: "/services/server"
  },
  {
    icon: Smartphone,
    title: "Mobile Device Recovery",
    description: "Data recovery for smartphones, tablets, and other mobile devices.",
    path: "/services/mobile"
  },
  {
    icon: Lock,
    title: "Encrypted Drive Recovery",
    description: "Specialized recovery for encrypted drives and secure storage systems.",
    path: "/services/encrypted"
  }
];

export function ServicesPage() {
  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-white mb-6"
          >
            Our Services
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-blue-100 max-w-2xl mx-auto"
          >
            Professional data recovery solutions for all storage devices
          </motion.p>
        </div>
      </div>

      {/* Services Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Link key={service.title} to={service.path}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-8 rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <service.icon className="w-12 h-12 text-blue-600 mb-6" />
                <h3 className="text-xl font-semibold mb-4">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-3xl font-bold mb-6">Need Emergency Data Recovery?</h2>
            <p className="text-xl text-gray-600 mb-8">
              Our team is available 24/7 for urgent data recovery needs.
              Don't wait - contact us now to start the recovery process.
            </p>
            <Link
              to="/contact"
              className="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700  transition-colors"
            >
              Contact Us Now
            </Link>
          </motion.div>
        </div>
      </div>
    </div>
  );
}