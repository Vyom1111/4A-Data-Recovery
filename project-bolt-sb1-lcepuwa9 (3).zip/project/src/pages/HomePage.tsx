import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Server, Clock, ArrowRight, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/Poster1.jpg?raw=true"
            alt="Data Recovery Banner"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/40" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <img src="https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/logo%204A.png?raw=true" alt="4A Data Recovery" className="h-16 mx-auto mb-8" />
            <h1 className="text-5xl font-bold text-white mb-6">
              Professional Data Recovery Solutions
            </h1>
            <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
              Expert data recovery services for businesses and individuals. We recover what matters most.
            </p>
            <Link to="/contact">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold flex items-center gap-2 mx-auto hover:bg-blue-700 transition-colors"
              >
                Get Started
                <ArrowRight className="w-5 h-5" />
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </header>

      {/* Business Card Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg p-8 flex flex-col md:flex-row items-center justify-between">
            <div className="mb-6 md:mb-0">
              <img src="https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/Visiting%20Card.jpg?raw=true" alt="4A Data Recovery" className="h-20 mb-4" />
              <h3 className="text-xl font-bold">Abhishek Gandhi</h3>
              <p className="text-gray-600">+91 9427080219</p>
              <p className="text-gray-600">F-3, Arjun Tower, C.P.Nagar,</p>
              <p className="text-gray-600">Karmachari Nagar Rd, Ahmedabad - 380061</p>
            </div>
            <div className="flex flex-col items-center">
              <Link to="/contact" className="btn btn-primary mb-4">
                Contact Now
              </Link>
              <p className="text-sm text-gray-500">Available 24/7 for emergencies</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center p-6 rounded-xl bg-gray-50"
            >
              <Shield className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Secure Recovery</h3>
              <p className="text-gray-600">Your data security is our top priority with encrypted recovery process.</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-center p-6 rounded-xl bg-gray-50"
            >
              <Server className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Advanced Technology</h3>
              <p className="text-gray-600">State-of-the-art equipment and recovery techniques.</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="text-center p-6 rounded-xl bg-gray-50"
            >
              <Clock className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Fast Recovery</h3>
              <p className="text-gray-600">Quick turnaround time with emergency service available.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {[
              { name: "Hard Drive Recovery", path: "/services/hard-drive" },
              { name: "SSD Data Recovery", path: "/services/ssd" },
              { name: "RAID Recovery", path: "/services/raid" },
              { name: "Server Recovery", path: "/services/server" },
              { name: "Mobile Device Recovery", path: "/services/mobile" },
              { name: "Encrypted Drive Recovery", path: "/services/encrypted" }
            ].map((service, index) => (
              <Link key={service.name} to={service.path}>
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-4 p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
                >
                  <CheckCircle className="w-6 h-6 text-blue-600 flex-shrink-0" />
                  <span className="text-lg text-gray-800">{service.name}</span>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}