import React from 'react';
import { motion } from 'framer-motion';
import { Award, Users, Building2, Globe } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative py-24 bg-gradient-to-r from-blue-600 to-blue-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <img src="https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/logo%204A.png?raw=true" alt="4A Data Recovery" className="h-16 mx-auto" />
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-white mb-6"
          >
            About 4A Data Recovery
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-blue-100 max-w-2xl mx-auto"
          >
            Leading the industry in professional data recovery solutions
          </motion.p>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {[
              { icon: Award, stat: "5+", label: "Years Experience" },
              { icon: Users, stat: "1,000+", label: "Satisfied Clients" },
              { icon: Building2, stat: "2", label: "Locations" },
              { icon: Globe, stat: "99%", label: "Success Rate" }
            ].map((item, index) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-6"
              >
                <item.icon className="w-8 h-8 text-blue-600 mx-auto mb-4" />
                <div className="text-3xl font-bold text-gray-900 mb-2">{item.stat}</div>
                <div className="text-gray-600">{item.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Story Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl font-bold text-center mb-8"
            >
              Our Story
            </motion.h2>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="prose prose-lg mx-auto"
            >
              <p className="mb-4">
                4A Data Recovery has established itself as a trusted name in data recovery services.
                Our commitment to excellence and customer satisfaction has made us a preferred choice
                for individuals and businesses facing data loss situations.
              </p>
              <p className="mb-4">
                With state-of-the-art facilities and expert technicians, we handle all types of data
                recovery cases, from simple drive failures to complex RAID systems and encrypted devices.
              </p>
              <p>
                Our success is built on a foundation of technical expertise, customer service, and
                a deep understanding of how critical your data is to you.
              </p>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Lab Photos Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl font-bold text-center mb-12"
          >
            Our State-of-the-Art Facility
          </motion.h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: "Shop Exterior", image: "https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/Exterior.png?raw=true" },
              { title: "Shop Exterior", image: "https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/Exterior2.png?raw=true" },
              { title: "Clean Room", image: "https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/Interior3.jpg?raw=true" },
              { title: "Interior", image: "https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/Interior1.png?raw=true" },
              { title: "Interior", image: "https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/Interior2.png?raw=true" },
              { title: "Visiting Card", image: "https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/Visiting%20Card.jpg?raw=true" }
            ].map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group relative overflow-hidden rounded-xl shadow-lg"
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-72 object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3 className="text-xl font-semibold text-white">{item.title}</h3>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}