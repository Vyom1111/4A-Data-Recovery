import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Youtube, MessageCircle } from 'lucide-react';

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <Link to="/" className="flex items-center gap-2">
              <img src="https://github.com/Vyom1111/4A-Data-Recovery/blob/4abe593eed0f37c3ca8ec0d32dff707b8448b99c/public/images/logo%204A.png?raw=true" alt="4A Data Recovery" className="h-8" />
              <span className="text-xl font-bold text-gray-900">4A Data Recovery</span>
            </Link>
            <div className="hidden md:flex space-x-8">
              <Link to="/services" className="text-gray-700 hover:text-blue-600">Services</Link>
              <Link to="/about" className="text-gray-700 hover:text-blue-600">About</Link>
              <Link to="/contact" className="text-gray-700 hover:text-blue-600">Contact</Link>
            </div>
            <Link to="/contact" className="btn btn-primary">Get Help Now</Link>
          </div>
        </div>
      </nav>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-400 hover:text-white">Home</Link></li>
                <li><Link to="/services" className="text-gray-400 hover:text-white">Services</Link></li>
                <li><Link to="/about" className="text-gray-400 hover:text-white">About</Link></li>
                <li><Link to="/contact" className="text-gray-400 hover:text-white">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Services</h3>
              <ul className="space-y-2">
                <li><Link to="#" className="text-gray-400 hover:text-white">Hard Drive Recovery</Link></li>
                <li><Link to="#" className="text-gray-400 hover:text-white">SSD Recovery</Link></li>
                <li><Link to="#" className="text-gray-400 hover:text-white">RAID Recovery</Link></li>
                <li><Link to="#" className="text-gray-400 hover:text-white">Mobile Recovery</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-gray-400">
                <li>+91 9427080219</li>
                <li>abhishekantim734@gmail.com</li>
                <li><a href="https://maps.app.goo.gl/p618dJ6nioeDp7FU8">Arjun Tower, F-F-3, CP Nagar 2, Ghatlodiya</a></li>
                <li>Ahmedabad, Gujarat 380061</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Hours</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Monday - Friday: 9am - 6pm</li>
                <li>Saturday: 10am - 4pm</li>
                <li>Sunday: Closed</li>
                <li>Emergency Service Available 24/7</li>
              </ul>
            </div>
          </div>
          <div className="mt-12 border-t border-gray-800 pt-8">
            <div className="flex justify-center space-x-6 mb-8">
              <a 
                href="https://www.instagram.com/4adatarecovery?igsh=NG8ycGpnYTd2czdh"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Instagram className="w-6 h-6" />
                <span className="sr-only">Instagram</span>
              </a>
              <a 
                href="https://youtube.com/@4adatarecovery?feature=shared"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Youtube className="w-6 h-6" />
                <span className="sr-only">YouTube</span>
              </a>
              <a 
                href="https://wa.me/919427080219"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <MessageCircle className="w-6 h-6" />
                <span className="sr-only">WhatsApp</span>
              </a>
            </div>
            <div className="text-center text-gray-400">
              <p>© 2024 4A Data Recovery AGM System Solutions. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}